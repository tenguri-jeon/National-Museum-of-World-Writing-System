let obj = [
    { id: 1, img: 'images/photo0.jpg', title: '고양이' },
    { id: 2, img: 'images/photo1.jpg', title: '강아지' },
];

export default obj;
